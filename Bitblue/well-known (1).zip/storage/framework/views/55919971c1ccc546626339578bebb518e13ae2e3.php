<?php echo $__env->make('./admin/adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('./admin/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- start page container -->
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <div class="page-title-breadcrumb">
                <div class=" pull-left">
                    <div class="page-title">Testimonial Information</div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="<?php echo e(asset('/')); ?>">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                    </li>
                    <li class="active">Testimonial Information</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-head">
                                <header>TESTIMONIAL TABLE</header>
                                <?php if(Session::has('success')): ?>
                                <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                                <?php endif; ?>
                                <?php if(Session::has('fail')): ?>
                                <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
                                <?php endif; ?>
                                <div class="tools">
                                    <!-- <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a> -->
                                    <a class="btn-color" href="add-testimonial"><button class="btn btn-primary">
                                            Add
                                        </button></a>
                                    <!-- <a class="t-close btn-color fa fa-times" href="javascript:;"></a> -->
                                </div>
                            </div>
                            <div class="card-body ">
                                <div class="table-responsive">
                                    <table class="table table-striped custom-table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Name</th>
                                                <th>Designation</th>
                                                <th>Rating</th>
                                                <th>Review</th>
                                                <th>Photo</th>
                                                <th class="pull-right">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key + 1); ?></td>
                                                <td><?php echo e($testimonial['name']); ?></td>
                                                <td><?php echo e($testimonial['designation']); ?></td>
                                                <td><?php echo e($testimonial['rating']); ?></td>
                                                <td>
                                                    <?php echo e($testimonial['review']); ?>

                                                </td>
                                                <td><img class="w-25 h-25" src="<?php echo e(asset('/testimonial')); ?>/<?php echo e($testimonial['image']); ?>" alt="">
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('edittestimonial',$testimonial['id'])); ?>">
                                                        <button class="btn btn-primary btn-xs">
                                                            <i class="fa fa-pencil"></i>
                                                        </button>
                                                    </a>
                                                    <a href="<?php echo e(route('deletetestimonial',$testimonial['id'])); ?>">
                                                        <button class="btn btn-danger btn-xs">
                                                            <i class="fa fa-trash-o "></i>
                                                        </button>
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('../admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/f0ow69h0nlnd/public_html/bitbluetech.com/resources/views/admin/pages/testimonial.blade.php ENDPATH**/ ?>