<!-- start sidebar menu -->
<div class="sidebar-container">
    <div class="sidemenu-container navbar-collapse collapse fixed-menu">
        <div id="remove-scroll" class="left-sidemenu">
            <ul class="sidemenu  page-header-fixed slimscroll-style" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
                <li class="sidebar-toggler-wrapper hide">
                    <div class="sidebar-toggler">
                        <span></span>
                    </div>
                </li>
                <li class="sidebar-user-panel">
                    <div class="sidebar-user">
                        <div class="sidebar-user-picture">
                            <img alt="image" src="<?php echo e(asset('./admin/img/dp.jpg')); ?>">
                        </div>
                        <div class="sidebar-user-details">
                            <div class="user-name">Admin</div>
                            <div class="user-role">Administrator</div>
                        </div>
                    </div>
                </li>
                <!-- <li class="nav-item start active open">
                    <a href="#" class="nav-link nav-toggle">
                        <i data-feather="airplay"></i>
                        <span class="title">Dashboard</span>
                        <span class="selected"></span>
                        <span class="arrow open"></span>
                    </a>
                    <ul class="sub-menu">
                        <li class="nav-item active">
                            <a href="index.html" class="nav-link ">
                                <span class="title">Dashboard 1</span>
                                <span class="selected"></span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a href="dashboard2.html" class="nav-link ">
                                <span class="title">Dashboard 2</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="dashboard3.html" class="nav-link ">
                                <span class="title">Dashboard 3</span>
                            </a>
                        </li>
                    </ul>
                </li> -->
                <li class="nav-item">
                    <a href="testimonials" class="nav-link nav-toggle"> <i data-feather="calendar"></i>
                        <span class="title">Testimonial</span>
                    </a>
                </li>


            </ul>
        </div>
    </div>
</div>
<!-- end sidebar menu --><?php /**PATH /home/f0ow69h0nlnd/public_html/bitbluetech.com/resources/views///admin/sidebar.blade.php ENDPATH**/ ?>