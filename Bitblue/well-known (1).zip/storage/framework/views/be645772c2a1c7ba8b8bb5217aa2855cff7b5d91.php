<div class="page-footer">
    <div class="page-footer-inner"> 2017 &copy; Smart University Theme By
        <a href="mailto:redstartheme@gmail.com" target="_top" class="makerCss">Redstar Theme</a>
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<!-- end footer -->
</div>
<!-- start js include path -->
<script src="./admin/plugins/jquery/jquery.min.js"></script>
<script src="./admin/plugins/popper/popper.js"></script>
<script src="./admin/plugins/jquery-blockui/jquery.blockui.min.js"></script>
<script src="./admin/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
<script src="./admin/plugins/feather/feather.min.js"></script>
<!-- bootstrap -->
<script src="./admin/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="./admin/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script src="./admin/plugins/sparkline/jquery.sparkline.js"></script>
<script src="./admin/js/pages/sparkline/sparkline-data.js"></script>
<!-- Common js-->
<script src="./admin/js/app.js"></script>
<script src="./admin/js/layout.js"></script>
<script src="./admin/js/theme-color.js"></script>
<!-- material -->
<script src="./admin/plugins/material/material.min.js"></script>
<!--apex chart-->
<script src="./admin/plugins/apexcharts/apexcharts.min.js"></script>
<script src="./admin/js/pages/chart/apex/home-data.js"></script>
<!-- summernote -->
<script src="./admin/plugins/summernote/summernote.js"></script>
<script src="./admin/js/pages/summernote/summernote-data.js"></script>
<!-- end js include path -->
</body>



</html><?php /**PATH /home/f0ow69h0nlnd/public_html/bitbluetech.com/resources/views////admin/footer.blade.php ENDPATH**/ ?>