<?php echo $__env->make('./page/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;


<?php echo $__env->make('./page/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\bitblue\resources\views/projects.blade.php ENDPATH**/ ?>