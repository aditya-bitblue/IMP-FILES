<!-- Main Footer -->
<footer class="main-footer style-three">
    <div class="pattern-layer" style="background-image: url(./public/user/images/background/pattern-3.png)"></div>
    <div class="pattern-layer-two" style="background-image: url(./public/user/images/background/pattern-4.png)"></div>
    <div class="pattern-layer-three" style="background-image: url(./public/user/images/background/pattern-5.png)"></div>
    <div class="auto-container">
        <!--Widgets Section-->
        <div class="widgets-section">
            <div class="row clearfix">

                <!-- Column -->
                <div class="big-column col-lg-6 col-md-12 col-sm-12">
                    <div class="row clearfix">

                        <!-- Footer Column -->
                        <div class="footer-column col-lg-7 col-md-6 col-sm-12">
                            <div class="footer-widget logo-widget">
                                <div class="logo">
                                    <a href="index.html"><img src="./public/user/images/bbw-logo.png" alt="" /></a>
                                </div>
                                <div class="text">Our approach to SEO is uniquely built around what we know works…and what we know doesn’t work. With over 200 verified factors in play.</div>
                                <!-- Social Box -->
                                <ul class="social-box">
                                    <li><a href="#" class="fa fa-facebook-f"></a></li>
                                    <li><a href="#" class="fa fa-linkedin"></a></li>
                                    <li><a href="#" class="fa fa-twitter"></a></li>
                                    <li><a href="#" class="fa fa-google"></a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- Footer Column -->
                        <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                            <div class="footer-widget links-widget">
                                <h4>Services</h4>
                                <ul class="list-link">
                                    <li><a href="#">SEO for Small Business</a></li>
                                    <li><a href="#">SEO for Local Services</a></li>
                                    <li><a href="#">Enterprise SEO</a></li>
                                    <li><a href="#">National SEO</a></li>
                                    <li><a href="#">International SEO</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- Column -->
                <div class="big-column col-lg-6 col-md-12 col-sm-12">
                    <div class="row clearfix">

                        <!--Footer Column-->
                        <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget gallery-widget">
                                <h4>instagram</h4>
                                <div class="widget-content">
                                    <div class="images-outer clearfix">
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="./public/user/images/gallery/1.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="./public/user/images/gallery/footer-gallery-thumb-1.jpg" alt=""></a></figure>
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="./public/user/images/gallery/2.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="./public/user/images/gallery/footer-gallery-thumb-2.jpg" alt=""></a></figure>
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="./public/user/images/gallery/3.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="./public/user/images/gallery/footer-gallery-thumb-3.jpg" alt=""></a></figure>
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="./public/user/images/gallery/4.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="./public/user/images/gallery/footer-gallery-thumb-4.jpg" alt=""></a></figure>
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="./public/user/images/gallery/1.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="./public/user/images/gallery/footer-gallery-thumb-5.jpg" alt=""></a></figure>
                                        <!--Image Box-->
                                        <figure class="image-box"><a href="./public/user/images/gallery/2.jpg" class="lightbox-image" data-fancybox="footer-gallery" title="Image Title Here" data-fancybox-group="footer-gallery"><img src="./public/user/images/gallery/footer-gallery-thumb-6.jpg" alt=""></a></figure>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Footer Column -->
                        <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                            <div class="footer-widget links-widget">
                                <h4>Contact info</h4>
                                <ul class="list-style-two">
                                    <li><span class="icon flaticon-wall-clock"></span>Mon – Sat 09:00pm - 6:30am</li>
                                    <li><span class="icon flaticon-phone-call"></span><a href="tel:+0987-654-321">0987 654 321</a> <a href="tel:+0123-456-789">0123 456 789</a></li>
                                    <li><span class="icon flaticon-email"></span><a href="mailto:contact@bitbluetech.com">contact@bitbluetech.com</a></li>
                                    <li><span class="icon flaticon-maps-and-flags"></span>G1, Oswal Nagri, Building No. 2A,
                                        Opp. Muthoot Finance, Next to Central Park,
                                        Nalasopara East - 401209.</li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="copyright">Copyright © 2016 by <a href="#">BitBlue Technology</a>. All Rights Reserved.</div>
        </div>

    </div>
</footer>
<!-- End Main Footer -->

</div>
<!--End pagewrapper-->

<!-- End Header Search -->

<!-- Scroll To Top -->
<div class="back-to-top scroll-to-target show-back-to-top" data-target="html">TOP</div>

<script src="user/js/jquery.js"></script>
<script src="user/js/popper.min.js"></script>
<script src="user/js/bootstrap.min.js"></script>
<script src="user/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="user/js/jquery.fancybox.js"></script>
<script src="user/js/appear.js"></script>
<script src="user/js/parallax.min.js"></script>
<script src="user/js/tilt.jquery.min.js"></script>
<script src="user/js/jquery.paroller.min.js"></script>
<script src="user/js/owl.js"></script>
<script src="user/js/wow.js"></script>
<script src="user/js/nav-tool.js"></script>
<script src="user/js/jquery-ui.js"></script>
<script src="user/js/script.js"></script>
<script src="user/js/color-settings.js"></script>

</body>

</html><?php /**PATH D:\bitblue\resources\views//page/footer.blade.php ENDPATH**/ ?>