<?php echo $__env->make('./page/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<style>
    .btn-primary {
        color: #fff;
        background-color: #1c3874;
        border-color: #0d6efd;
    }
</style>
<!-- Page Title Section -->
<section class="page-title" style="background-image: url(images/main-slider/image-2.jpg)">
    <div class="pattern-layer-one" style="background-image: url(images/main-slider/pattern-1.png)"></div>
    <div class="pattern-layer-two" style="background-image: url(images/background/pattern-17.png)"></div>
    <div class="pattern-layer-three" style="background-image: url(images/background/pattern-18.png)"></div>
    <div class="pattern-layer-four" style="background-image: url(images/icons/cross-icon.png)"></div>
    <div class="auto-container">
        <h2>Career</h2>
        <ul class="page-breadcrumb">
            <li><a href="index.html">home</a></li>
            <li>Career</li>
        </ul>
    </div>
</section>
<!-- End Page Title Section -->

<!-- Contact Info Section -->
<section class="contact-info-section">
    <div class="auto-container">
        <!-- Sec Title -->
        <div class="sec-title centered">
            <div class="title">Steps Towards Career</div>
            <h2>Join Our Team</h2>
            <div class="text">Do you find a passion in solving business problems utilizing modern technolgies?<br> We are building products for future with a mission to tap the mobile market .Come Join Us!!</div>
        </div>

        <div class="row">
            <div class="auto-container">
                <!-- Sec Title -->
                <div class="sec-title centered">
                    <div class="title">We are always looking for people who can make a difference at Bitblue and are passionate about technology. If you don't find any open position below, you can still apply with your resume.

                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="service-block-three rounded-0 ">
                    <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="icon-box">
                            <img src="images/app-development.png" class="icon" />
                            <button class="btn btn-primary pull-right btn-sm">Apply Now</button>
                        </div>
                        <h5><a href="#">Software Developer</a></h5>
                        <div class="text">We are looking for developers who can build interesting use cases utilizing modern technologies.</div>
                        <h6><a href="#">Eligibility: BE/BTech/MCA</a></h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="service-block-three rounded-0 ">
                    <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="icon-box">
                            <img src="images/circuit-board.png" class="icon" />
                            <button class="btn btn-primary pull-right btn-sm">Apply Now</button>
                        </div>
                        <h5><a href="#">Hardware/Network Engineer</a></h5>
                        <div class="text">Do you like hacking inside networks and computer systems? We need you to manage our IT infrastructure.</div>
                        <h6><a href="#">Eligibility: BE/BTech/MCA</a></h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="service-block-three rounded-0 ">
                    <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="icon-box">
                            <img src="images/analytics.png" class="icon" />
                            <button class="btn btn-primary pull-right btn-sm">Apply Now</button>
                        </div>
                        <h5><a href="#">Marketing Executive</a></h5>
                        <div class="text">Do you have the go-getter attitude? If yes, then we are looking for rockstars like you to join us.</div>
                        <h6><a href="#">Eligibility: Graduate/BBA/MBA</a></h6>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- End Contact Info Section -->


<!-- End Contact Form Section -->
<?php echo $__env->make('./page/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\bitblue\resources\views/career.blade.php ENDPATH**/ ?>