<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>BitBlue Technology</title>
    <!-- Stylesheets -->
    <link href="./user/css/bootstrap.css" rel="stylesheet">
    <link href="./user/css/style.css" rel="stylesheet">
    <link href="./user/css/responsive.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700&amp;family=Poppins:wght@300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet">

    <!-- Color Switcher Mockup -->
    <link href="./user/css/color-switcher-design.css" rel="stylesheet">

    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="icon" href="./user/images/favicon.png" type="image/x-icon">

    <!-- Responsive -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

</head>

<body class="hidden-bar-wrapper">

    <div class="page-wrapper">

        <!-- Preloader -->
        <div class="preloader">
            <div class="box"></div>
        </div>

        <!-- Main Header-->
        <header class="main-header header-style-one">

            <!--Header-Upper-->
            <div class="header-upper">
                <div class="auto-container clearfix">

                    <div class="pull-left logo-box">
                        <div class="logo"><a href="/"><img src="./user/images/bbw-logo.png" alt="" title=""></a></div>
                    </div>

                    <div class="nav-outer clearfix">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
                        <!-- Main Menu -->
                        <nav class="main-menu navbar-expand-md">
                            <div class="navbar-header">
                                <!-- Toggle Button -->
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>

                            <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">
                                    <li class=""><a href="/">Home</a>

                                    </li>
                                    <li class="dropdown"><a href="about-us">About</a>
                                        <!-- <ul>
                                            <li><a href="about-us">About Us</a></li>

                                        </ul> -->
                                    </li>
                                    <li class="dropdown"><a href="services">Services</a>
                                        <ul>
                                            <!-- <li><a href="services">Services</a></li> -->
                                            <li><a href="services">Dextro ATF</a></li>
                                            <li><a href="services">Digital school broadcast system</a></li>
                                            <li><a href="services">Bit smart projector</a></li>
                                            <li><a href="services">Bio metric Attendance</a></li>
                                            <li><a href="services">CCTV system</a></li>
                                            <li><a href="services">Computer Lab</a></li>
                                            <li><a href="services">ID Card printer</a></li>
                                            <li><a href="services">Badges</a></li>
                                            <li><a href="services">Printer</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="product">Product</a>
                                        <ul>
                                            <li><a href="dextro">Dextro</a></li>
                                            <li><a href="pabulum">Pabulum</a></li>
                                            <li><a href="hospo">Hospo</a></li>
                                            <li><a href="bithome">Bithome</a></li>
                                            <li><a href="digitalmarketing">Digital Marketing</a></li>
                                            <li><a href="bitpay">Bitpay</a></li>
                                            <li><a href="mobileapplication">Mobile Application</a></li>
                                            <li><a href="webdevelopment">Web Development</a></li>
                                        </ul>
                                    </li>

                                    <li class="dropdown"><a href="career">Career</a>
                                        <ul>
                                            <li><a href="shop.html">Our Products</a></li>
                                            <li><a href="shop-single.html">Product Single</a></li>
                                            <li><a href="shopping-cart.html">Shopping Cart</a></li>
                                            <li><a href="checkout.html">Checkout</a></li>
                                            <li><a href="account.html">Account</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="#">Pages</a>
                                        <ul>
                                            <li><a href="blog.html">Our Blog</a></li>
                                            <li><a href="blog-classic.html">Blog Classic</a></li>
                                            <li><a href="blog-left-sidebar.html">Blog Left Sidebar</a></li>
                                            <li><a href="aboutnew">Blog Single</a></li>
                                            <li><a href="not-found.html">Not Found</a></li>
                                            <li><a href="login">login</a></li>
                                            <li><a href="registration">registration</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="contact">Contact us</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
            <!--End Header Upper-->

            <!-- Sticky Header  -->
            <div class="sticky-header">
                <div class="auto-container clearfix">
                    <!--Logo-->
                    <div class="logo pull-left">
                        <a href="index.html" title=""><img src="./user/images/bbw-logo-small.png" alt="" title=""></a>
                    </div>
                    <!--Right Col-->
                    <div class="pull-right">
                        <!-- Main Menu -->
                        <nav class="main-menu">
                            <!--Keep This Empty / Menu will come through Javascript-->
                        </nav><!-- Main Menu End-->

                        <!-- Main Menu End-->


                    </div>
                </div>
            </div><!-- End Sticky Menu -->

            <!-- Mobile Menu  -->
            <div class="mobile-menu">
                <div class="menu-backdrop"></div>
                <div class="close-btn"><span class="icon flaticon-multiply"></span></div>

                <nav class="menu-box">
                    <div class="nav-logo"><a href="index.html"><img src="images/logo-3.png" alt="" title=""></a></div>
                    <div class="menu-outer">
                        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                    </div>
                </nav>
            </div><!-- End Mobile Menu -->

        </header>
        <!-- End Main Header --><?php /**PATH C:\bitblue\resources\views///page/header.blade.php ENDPATH**/ ?>