<!-- <?php echo $__env->make('./page/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; -->
<?php echo $__env->yieldContent('content'); ?>

<!-- Banner Section Four -->
<section class="banner-section-four">
    <div class="main-slider-carousel owl-carousel owl-theme">

        <div class="slide" style="background-image: url(images/main-slider/image-2.jpg)">
            <div class="dotted-layer" style="background-image: url(images/main-slider/dotted-layer-1.png)"></div>
            <div class="auto-container">
                <div class="row clearfix">

                    <!-- Content Column -->
                    <div class="content-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title">What’s Your SEO Score</div>
                            <h1>SEO Services Provide <br> For Your Agency</h1>
                            <div class="btns-box">
                                <a href="about.html" class="theme-btn btn-style-eight"><span class="txt">Lets Start</span></a>
                                <a href="contact.html" class="theme-btn btn-style-nine"><span class="txt">Contact Now</span></a>
                            </div>
                        </div>
                    </div>

                    <!-- Image Column -->
                    <div class="image-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="image">
                                <img src="images/main-slider/content-image-2.png" alt="" />
                            </div>
                            <div class="images-icons parallax-scene-1">
                                <div class="image-1" data-depth="0.50">
                                    <img src="images/main-slider/content-image-3.png" alt="" />
                                </div>
                                <div class="image-2" data-depth="0.50">
                                    <img src="images/main-slider/content-image-4.png" alt="" />
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

        <div class="slide" style="background-image: url(images/main-slider/image-2.jpg)">
            <div class="dotted-layer" style="background-image: url(images/main-slider/dotted-layer-1.png)"></div>
            <div class="auto-container">
                <div class="row clearfix">

                    <!-- Content Column -->
                    <div class="content-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title">What’s Your SEO Score</div>
                            <h1>SEO Services Provide <br> For Your Agency</h1>
                            <div class="btns-box">
                                <a href="about.html" class="theme-btn btn-style-eight"><span class="txt">Lets Start</span></a>
                                <a href="contact.html" class="theme-btn btn-style-nine"><span class="txt">Contact Now</span></a>
                            </div>
                        </div>
                    </div>

                    <!-- Image Column -->
                    <div class="image-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="image">
                                <img src="images/main-slider/content-image-2.png" alt="" />
                            </div>
                            <div class="images-icons parallax-scene-1">
                                <div class="image-1" data-depth="0.50">
                                    <img src="images/main-slider/content-image-3.png" alt="" />
                                </div>
                                <div class="image-2" data-depth="0.50">
                                    <img src="images/main-slider/content-image-4.png" alt="" />
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

        <div class="slide" style="background-image: url(images/main-slider/image-2.jpg)">
            <div class="dotted-layer" style="background-image: url(images/main-slider/dotted-layer-1.png)"></div>
            <div class="auto-container">
                <div class="row clearfix">

                    <!-- Content Column -->
                    <div class="content-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title">What’s Your SEO Score</div>
                            <h1>SEO Services Provide <br> For Your Agency</h1>
                            <div class="btns-box">
                                <a href="about.html" class="theme-btn btn-style-eight"><span class="txt">Lets Start</span></a>
                                <a href="contact.html" class="theme-btn btn-style-nine"><span class="txt">Contact Now</span></a>
                            </div>
                        </div>
                    </div>

                    <!-- Image Column -->
                    <div class="image-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="image">
                                <img src="images/main-slider/content-image-2.png" alt="" />
                            </div>
                            <div class="images-icons parallax-scene-1">
                                <div class="image-1" data-depth="0.50">
                                    <img src="images/main-slider/content-image-3.png" alt="" />
                                </div>
                                <div class="image-2" data-depth="0.50">
                                    <img src="images/main-slider/content-image-4.png" alt="" />
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
    <!-- Waves Container -->
    <div>
        <svg class="waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28" preserveAspectRatio="none" shape-rendering="auto">
            <defs>
                <path id="gentle-wave" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z" />
            </defs>
            <g class="parallax">
                <use xlink:href="#gentle-wave" x="48" y="0" fill="rgba(255,255,255,0.7" />
                <use xlink:href="#gentle-wave" x="48" y="3" fill="rgba(255,255,255,0.5)" />
                <use xlink:href="#gentle-wave" x="48" y="5" fill="rgba(255,255,255,0.3)" />
                <use xlink:href="#gentle-wave" x="48" y="7" fill="#fff" />
            </g>
        </svg>
    </div>
    <!-- Waves End -->
</section>
<!-- End Banner Section -->



<?php echo $__env->make('/page/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\bitblue\resources\views//page/index.blade.php ENDPATH**/ ?>