<?php

namespace App\Http\Controllers;

use App\Models\Testimonial;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class AdminHomeController extends Controller
{
    public function dashboard()
    {
        return view('admin/dashboard');
    }
    public function testimonial()
    {
        $data = Testimonial::where('status', 1)->get();
        return view('admin/pages/testimonial', compact('data'));
    }
    public function addtestimonial()
    {
        // return $data;
        return view('admin/pages/addtestimonial');
    }
    public function uploadtestimonial(Request $req)
    {
        // return $req;
        // die;
        $req->validate([
            'name' => 'required',
            'rating' => 'required|max:5|min:1|numeric',
            'review' => 'required',
            'designation' => 'required',
            'image' => 'required',
        ]);
        $data = new Testimonial();
        if ($req->file('image')) {
            $file = $req->file('image');
            $filename = date('YmdHi') . $file->getClientOriginalName();
            $file->move(public_path('./testimonial'), $filename);
            $data['image'] = $filename;

            $data->name = $req['name'];
            $data->rating = $req['rating'];
            $data->review = $req['review'];
            $data->designation = $req['designation'];
            $data->image = $filename;
            $data = $data->save();
            if ($data) {
                return back()->with('success', 'You have registerd Successfuly');
            } else {
                return back()->with('fail', 'Something Went wrong');
            }
        } else {
            return back()->with('fail', 'Please select valid image');
        }
    }

    public function edittestimonial(Request $req, $id)
    {
        // return $id;
        $data = Testimonial::where('id', $id)->get();
        return view('admin/pages/edittestimonial', compact('data'));
    }

    public function updatetestimonial(Request $req, $id)
    {
        // return $_FILES;
        $req->validate([
            'name' => 'required',
            'rating' => 'required|max:5|min:1|numeric',
            'review' => 'required',
            'designation' => 'required',
        ]);
        if ($req['edittestimonial'] == 'edittestimonial') {
            $data = Testimonial::find($id);
            if ($req->file('image')) {

                $file = $req->file('image');
                $filename = date('YmdHi') . $file->getClientOriginalName();
                $file->move(public_path('./testimonial'), $filename);
                $data['image'] = $filename;

                $data->name = $req['name'];
                $data->rating = $req['rating'];
                $data->review = $req['review'];
                $data->designation = $req['designation'];
                $data->image = $filename;
                $data->update();
                return back()->with('success', 'Record Updated Successfuly');
            } else {

                $data->name = $req['name'];
                $data->rating = $req['rating'];
                $data->review = $req['review'];
                $data->designation = $req['designation'];
                $data->update();
                return back()->with('success', 'Record Updated Successfuly');
            }
        } else {
            return back()->with('fail', 'Please select valid image');
        }
    }

    public function deletetestimonial(Request $req, $id)
    {
        // return $id;
        $date = Carbon::now()->format('d-m-Y H:i:s');
        $result = Testimonial::where('id', $id)->first();
        $result->status = '0';
        $result->deleted_at = $date;
        $result->save();
        if ($result) {
            return back()->with('success', 'Record is deleted successfully');
        }
    }
}
