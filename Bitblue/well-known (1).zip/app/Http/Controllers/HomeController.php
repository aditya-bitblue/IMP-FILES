<?php

namespace App\Http\Controllers;

use App\Models\Testimonial;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $data = Testimonial::where('status', 1)->get();
        return view('page/index', compact('data'));
    }
    public function contact()
    {
        return view('contact');
    }
    public function aboutus()
    {
        return view('about');
    }
    public function services()
    {
        return view('services');
    }
    public function career()
    {
        return view('career');
    }
    public function product()
    {
        return view('product');
    }
    public function appdevelopment()
    {
        return view('product/appdevelopment');
    }
    public function webdevelopment()
    {
        return view('product/webdevelopment');
    }
    public function contentmarketing()
    {
        return view('product/contentmarketing');
    }
    public function seooptimization()
    {
        return view('product/seooptimization');
    }
    public function socialmarketing()
    {
        return view('product/socialmarketing');
    }
    public function dextro()
    {
        return view('product/dextro');
    }
    public function pabulum()
    {
        return view('product/pabulum');
    }
    public function hospo()
    {
        return view('product/hospo');
    }
    public function bithome()
    {
        return view('product/bithome');
    }
    public function digitalmarketing()
    {
        return view('product/digitalmarketing');
    }
    public function bitpay()
    {
        return view('product/bitpay');
    }
    public function jobapply1()
    {
        $position = 'Software Developer';
        return view('./apply', compact('position'));
    }
    public function jobapply2()
    {
        $position = 'Hardware/Network Engineer';
        return view('./apply', compact('position'));
    }
    public function jobapply3()
    {
        $position = 'Marketing Executive';
        return view('./apply', compact('position'));
    }
}
