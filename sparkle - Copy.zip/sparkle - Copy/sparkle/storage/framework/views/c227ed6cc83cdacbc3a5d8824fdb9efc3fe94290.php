<!--*********************************************************
            Footer start
        ***********************************-->
<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed by <a href="https://bitbluetech.com/index.php" target="_blank">BitBlue Technology</a> 2022</p>
    </div>
</div>
<!--**********************************
            Footer end
        ***********************************-->

<!--**********************************
           Support ticket button start
        ***********************************-->

<!--**********************************
           Support ticket button end
        ***********************************-->


</div>
<!--**********************************
        Main wrapper end
    ***********************************-->

<!--**********************************
        Scripts
    ***********************************-->

<!-- Required vendors -->


<script src="/assets/js/jquery.magnific-popup.min.js"></script>

<script src="/assets/js/main.js"></script>

<!-- Slider Revolution core JavaScript files -->
<script src="/assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="/assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="/assets/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="/assets/js/rev-slider-custom.js"></script>
<script src="/xhtml/vendor/global/global.min.js"></script>
<script src="/xhtml/vendor/chart.js/Chart.bundle.min.js"></script>
<script src="/xhtml/vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>

<!-- Apex Chart -->
<script src="/xhtml/vendor/apexchart/apexchart.js"></script>

<script src="/xhtml/vendor/bootstrap-datetimepicker/js/moment.js"></script>
<script src="/xhtml/vendor/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>

<!-- Dashboard 1 -->
<script src="/xhtml/js/dashboard/dashboard-1.js"></script>

<script src="/xhtml/js/custom.js"></script>
<script src="/xhtml/js/dlabnav-init.js"></script>
<script src="/xhtml/js/demo.js"></script>
<script src="/xhtml/js/styleSwitcher.js"></script>
<!-- <script>
        $(function() {
            $('#datetimepicker').datetimepicker({
                inline: true,
            });
        });

        $(document).ready(function() {
            $(".booking-calender .fa.fa-clock-o").removeClass(this);
            $(".booking-calender .fa.fa-clock-o").addClass('fa-clock');
        });
    </script> --><?php /**PATH C:\Users\Acer Nitro 5\Desktop\Aditya Vartak\sparkle\sparkle\resources\views///admin/footerdash.blade.php ENDPATH**/ ?>