@include('header')
<!-- Start Page Title Area -->
<div class="page-title-area page-title-style-two item-bg3 jarallax" data-jarallax='{"speed": 0.3}'>
    <div class="container">
        <div class="page-title-content">
            <ul>
                <li><a href="/">Home</a></li>
                <li>Certificate</li>
            </ul>
            <h2>Certificate</h2>
        </div>
    </div>
</div>
<!-- End Page Title Area -->

<!-- Start Courses Categories Area -->
<section class="courses-categories-area ptb-100">
    <div class="container">
        <div class="row-new">
            <div class="m-5 col-lg-3 col-md-4 col-sm-6">
                <a href="#">
                    <div class="single-categories-courses-item bg">

                    </div>
                </a>
                <h1 class="learn-more-btn">Extract of Annual Return MGT-9-2018</h1>
            </div>
            <div class="m-5 col-lg-3 col-md-4 col-sm-6">
                <a href="#">
                    <div class="single-categories-courses-item bg">

                    </div>
                </a>
                <h1 class="learn-more-btn">Extract of Annual Return MGT-9-2018</h1>
            </div>
            <div class="m-5 col-lg-3 col-md-4 col-sm-6">
                <a href="#">
                    <div class="single-categories-courses-item bg">

                    </div>
                </a>
                <h1 class="learn-more-btn">Extract of Annual Return MGT-9-2018</h1>
            </div>
            <div class="m-5 col-lg-3 col-md-4 col-sm-6">
                <a href="#">
                    <div class="single-categories-courses-item bg">

                    </div>
                </a>
                <h1 class="learn-more-btn">Extract of Annual Return MGT-9-2018</h1>
            </div>
            <div class="m-5 col-lg-3 col-md-4 col-sm-6">
                <a href="#">
                    <div class="single-categories-courses-item bg">

                    </div>
                </a>
                <h1 class="learn-more-btn">Extract of Annual Return MGT-9-2018</h1>
            </div>
            <div class="m-5 col-lg-3 col-md-4 col-sm-6">
                <a href="#">
                    <div class="single-categories-courses-item bg">

                    </div>
                </a>
                <h1 class="learn-more-btn">Extract of Annual Return MGT-9-2018</h1>
            </div>
        </div>
    </div>

    <!-- <div id="particles-js-circle-bubble-2"></div> -->
</section>
<!-- End Courses Categories Area -->


@include('footer')