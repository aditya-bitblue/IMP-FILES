@include('header')
<div class="page-title-area page-title-style-two item-bg3 jarallax" data-jarallax='{"speed": 0.3}'>
    <div class="container">
        <div class="page-title-content">
            <ul>
                <li><a href="/">Home</a></li>
                <li>Holiday List</li>
            </ul>
            <h2>Holiday List</h2>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row align-items-center">
        <div class="col-lg-6 col-md-12">
            <div class="about-content left-content">
                <br />
                <br />
                <br />
                <h2>Holidays List</h2>
                <!-- <h6>We can support student forum 24/7 for national and international students.</h6> -->
                <p>Coming soon .........</p>



            </div>
            <br />
            </br>
            </br>
            </br>


        </div>



    </div>
</div>

@include('footer')