@include('header')

<body>
    <div class="page-title-area page-title-style-two item-bg3 jarallax" data-jarallax='{"speed": 0.3}'>
        <div class="container">
            <div class="page-title-content">
                <ul>
                    <li><a class="text-black" href="/">Home</a></li>
                    <li class="text-black">PTA</li>
                </ul>
                <h2 class="text-black">Parents Involvement</h2>
            </div>
        </div>
    </div>
    <!-- End Page Title Area -->
    <div class="row align-items-center">
        <div class="col-lg-6 col-md-12">
            <div class="about-content left-content">
                <br />
                <br />
                <br />
                <h2>Parents Invlovement</h2>
                <!-- <h6>We can support student forum 24/7 for national and international students.</h6> -->
                <p>Coming soon .........</p>



            </div>
            <br />
            </br>
            </br>
            </br>


        </div>



    </div>
</body>

@include('footer')