<a href="/">
    <h1> clear your cache by hitting this statement</h1>
</a>

@include('footer')